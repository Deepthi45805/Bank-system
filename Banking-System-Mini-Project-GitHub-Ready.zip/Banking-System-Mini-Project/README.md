# Banking System – Mini Project

A Python-based mini banking application that simulates basic banking operations through a menu-driven program.

## Features

- Create a bank account
- Generate a unique account number
- Create and confirm a 4-digit PIN
- Login using Account Number and PIN
- Check account balance
- Deposit money
- Withdraw money with balance validation
- Transfer money between accounts
- View transaction history
- Change PIN
- Logout
- Save account data so it remains available after restarting the program

## Python Concepts Used

- Variables and data types
- Conditional statements
- Loops
- Functions
- Lists and dictionaries
- String operations
- Modules
- File handling
- JSON data storage
- Exception handling

## Modules Used

- `random` – generates account numbers
- `datetime` – records transaction date and time
- `json` – stores account data
- `os` – checks whether the data file exists

## Project Structure

```text
Banking-System-Mini-Project/
│
├── main.py
├── accounts.json
├── README.md
└── .gitignore
```

## How to Run

### 1. Install Python

Python 3.8 or later is recommended.

### 2. Clone the repository

```bash
git clone <YOUR-GITHUB-REPOSITORY-URL>
cd Banking-System-Mini-Project
```

### 3. Run the program

```bash
python main.py
```

On some systems:

```bash
python3 main.py
```

## Main Menu

```text
1. Create Account
2. Login
3. Exit
```

After login:

```text
1. Check Balance
2. Deposit
3. Withdraw
4. Transfer
5. Transaction History
6. Change PIN
7. Logout
```

## Important Note

This is an educational mini-project, not a real banking application. The PIN is stored locally for demonstration purposes and is not encrypted. Do not use this project for real financial information.

## Project Objective

The objective is to combine Python concepts into one real-world application and understand how individual programming concepts work together to build a functional system.

## Author

Student Mini Project – Banking System
