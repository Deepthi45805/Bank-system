import random
from datetime import datetime
import json
import os

DATA_FILE = "accounts.json"


def load_accounts():
    """Load account data from the JSON file."""
    if not os.path.exists(DATA_FILE):
        return {}

    try:
        with open(DATA_FILE, "r", encoding="utf-8") as file:
            return json.load(file)
    except (json.JSONDecodeError, OSError):
        return {}


def save_accounts(accounts):
    """Save account data to the JSON file."""
    with open(DATA_FILE, "w", encoding="utf-8") as file:
        json.dump(accounts, file, indent=4)


def generate_account_number(accounts):
    """Generate a unique 10-digit account number."""
    while True:
        account_number = str(random.randint(1000000000, 9999999999))
        if account_number not in accounts:
            return account_number


def valid_pin(pin):
    return pin.isdigit() and len(pin) == 4


def get_amount(prompt):
    """Read a positive money amount."""
    while True:
        try:
            amount = float(input(prompt))
            if amount <= 0:
                print("Amount must be greater than 0.")
                continue
            return amount
        except ValueError:
            print("Please enter a valid number.")


def add_transaction(account, transaction_type, amount, details=""):
    account["transactions"].append({
        "date_time": datetime.now().strftime("%d-%m-%Y %H:%M:%S"),
        "type": transaction_type,
        "amount": round(amount, 2),
        "details": details
    })


def create_account(accounts):
    print("\n========== CREATE ACCOUNT ==========")

    name = input("Enter your name: ").strip()
    while not name:
        print("Name cannot be empty.")
        name = input("Enter your name: ").strip()

    phone = input("Enter phone number: ").strip()
    while not phone.isdigit() or len(phone) != 10:
        print("Enter a valid 10-digit phone number.")
        phone = input("Enter phone number: ").strip()

    while True:
        pin = input("Create a 4-digit PIN: ").strip()
        if valid_pin(pin):
            confirm_pin = input("Confirm PIN: ").strip()
            if pin == confirm_pin:
                break
            print("PINs do not match.")
        else:
            print("PIN must contain exactly 4 digits.")

    account_number = generate_account_number(accounts)

    accounts[account_number] = {
        "name": name,
        "phone": phone,
        "pin": pin,
        "balance": 0.0,
        "transactions": []
    }

    save_accounts(accounts)

    print("\nAccount created successfully!")
    print(f"Your Account Number is: {account_number}")
    print("Please remember your account number and PIN.")


def login(accounts):
    print("\n========== LOGIN ==========")
    account_number = input("Enter account number: ").strip()
    pin = input("Enter PIN: ").strip()

    account = accounts.get(account_number)

    if account and account["pin"] == pin:
        print(f"\nWelcome, {account['name']}!")
        return account_number

    print("Invalid account number or PIN.")
    return None


def check_balance(account):
    print(f"\nCurrent Balance: ₹{account['balance']:.2f}")


def deposit(accounts, account_number):
    account = accounts[account_number]
    print("\n========== DEPOSIT ==========")
    amount = get_amount("Enter amount to deposit: ₹")

    account["balance"] = round(account["balance"] + amount, 2)
    add_transaction(account, "Deposit", amount, "Money deposited")
    save_accounts(accounts)

    print(f"₹{amount:.2f} deposited successfully.")
    print(f"New Balance: ₹{account['balance']:.2f}")


def withdraw(accounts, account_number):
    account = accounts[account_number]
    print("\n========== WITHDRAW ==========")
    amount = get_amount("Enter amount to withdraw: ₹")

    if amount > account["balance"]:
        print("Insufficient balance.")
        return

    account["balance"] = round(account["balance"] - amount, 2)
    add_transaction(account, "Withdrawal", amount, "Money withdrawn")
    save_accounts(accounts)

    print(f"₹{amount:.2f} withdrawn successfully.")
    print(f"New Balance: ₹{account['balance']:.2f}")


def transfer(accounts, sender_number):
    sender = accounts[sender_number]
    print("\n========== TRANSFER ==========")

    receiver_number = input("Enter receiver account number: ").strip()

    if receiver_number == sender_number:
        print("You cannot transfer money to your own account.")
        return

    if receiver_number not in accounts:
        print("Receiver account not found.")
        return

    amount = get_amount("Enter amount to transfer: ₹")

    if amount > sender["balance"]:
        print("Insufficient balance.")
        return

    receiver = accounts[receiver_number]

    sender["balance"] = round(sender["balance"] - amount, 2)
    receiver["balance"] = round(receiver["balance"] + amount, 2)

    add_transaction(
        sender,
        "Transfer Sent",
        amount,
        f"To account {receiver_number}"
    )
    add_transaction(
        receiver,
        "Transfer Received",
        amount,
        f"From account {sender_number}"
    )

    save_accounts(accounts)

    print(f"₹{amount:.2f} transferred successfully.")
    print(f"New Balance: ₹{sender['balance']:.2f}")


def transaction_history(account):
    print("\n========== TRANSACTION HISTORY ==========")

    transactions = account["transactions"]

    if not transactions:
        print("No transactions yet.")
        return

    for number, transaction in enumerate(transactions, start=1):
        print(
            f"{number}. {transaction['date_time']} | "
            f"{transaction['type']} | "
            f"₹{transaction['amount']:.2f} | "
            f"{transaction['details']}"
        )


def change_pin(accounts, account_number):
    account = accounts[account_number]
    print("\n========== CHANGE PIN ==========")

    old_pin = input("Enter old PIN: ").strip()

    if old_pin != account["pin"]:
        print("Incorrect old PIN.")
        return

    while True:
        new_pin = input("Enter new 4-digit PIN: ").strip()

        if not valid_pin(new_pin):
            print("PIN must contain exactly 4 digits.")
            continue

        confirm_pin = input("Confirm new PIN: ").strip()

        if new_pin != confirm_pin:
            print("PINs do not match.")
            continue

        if new_pin == old_pin:
            print("New PIN must be different from old PIN.")
            continue

        account["pin"] = new_pin
        save_accounts(accounts)
        print("PIN changed successfully.")
        return


def account_menu(accounts, account_number):
    while True:
        account = accounts[account_number]

        print("\n======================================")
        print("             ACCOUNT MENU")
        print("======================================")
        print("1. Check Balance")
        print("2. Deposit")
        print("3. Withdraw")
        print("4. Transfer")
        print("5. Transaction History")
        print("6. Change PIN")
        print("7. Logout")
        print("======================================")

        choice = input("Enter your choice: ").strip()

        if choice == "1":
            check_balance(account)
        elif choice == "2":
            deposit(accounts, account_number)
        elif choice == "3":
            withdraw(accounts, account_number)
        elif choice == "4":
            transfer(accounts, account_number)
        elif choice == "5":
            transaction_history(account)
        elif choice == "6":
            change_pin(accounts, account_number)
        elif choice == "7":
            print("\nLogged out successfully.")
            break
        else:
            print("Invalid choice. Please select 1-7.")


def main():
    accounts = load_accounts()

    while True:
        print("\n======================================")
        print("          BANKING SYSTEM")
        print("======================================")
        print("1. Create Account")
        print("2. Login")
        print("3. Exit")
        print("======================================")

        choice = input("Enter your choice: ").strip()

        if choice == "1":
            create_account(accounts)
        elif choice == "2":
            account_number = login(accounts)
            if account_number:
                account_menu(accounts, account_number)
        elif choice == "3":
            print("\nThank you for using the Banking System!")
            break
        else:
            print("Invalid choice. Please select 1-3.")


if __name__ == "__main__":
    main()
