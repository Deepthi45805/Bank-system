import streamlit as st
import random
from datetime import datetime
import json
import os

DATA_FILE = "accounts.json"


# -----------------------------
# DATA FUNCTIONS
# -----------------------------
def load_accounts():
    if not os.path.exists(DATA_FILE):
        return {}

    try:
        with open(DATA_FILE, "r", encoding="utf-8") as file:
            return json.load(file)
    except (json.JSONDecodeError, OSError):
        return {}


def save_accounts(accounts):
    with open(DATA_FILE, "w", encoding="utf-8") as file:
        json.dump(accounts, file, indent=4)


def generate_account_number(accounts):
    while True:
        account_number = str(random.randint(1000000000, 9999999999))
        if account_number not in accounts:
            return account_number


def add_transaction(account, transaction_type, amount, details=""):
    account["transactions"].append({
        "date_time": datetime.now().strftime("%d-%m-%Y %H:%M:%S"),
        "type": transaction_type,
        "amount": round(amount, 2),
        "details": details
    })


def valid_pin(pin):
    return pin.isdigit() and len(pin) == 4


def reset_session():
    st.session_state.logged_in = False
    st.session_state.account_number = None


# -----------------------------
# PAGE CONFIGURATION
# -----------------------------
st.set_page_config(
    page_title="Banking System",
    page_icon="🏦",
    layout="centered"
)

st.title("🏦 Banking System")
st.caption("Python + Streamlit Mini Project")

# Initialize session state
if "logged_in" not in st.session_state:
    st.session_state.logged_in = False

if "account_number" not in st.session_state:
    st.session_state.account_number = None

accounts = load_accounts()


# ============================================================
# LOGGED-IN USER
# ============================================================
if st.session_state.logged_in:
    account_number = st.session_state.account_number

    # Account may have been deleted/changed externally
    if account_number not in accounts:
        reset_session()
        st.rerun()

    account = accounts[account_number]

    st.success(f"Welcome, {account['name']}! 👋")
    st.info(f"Account Number: {account_number}")

    menu = st.radio(
        "Account Menu",
        [
            "💰 Check Balance",
            "➕ Deposit",
            "➖ Withdraw",
            "🔄 Transfer",
            "📜 Transaction History",
            "🔐 Change PIN",
            "🚪 Logout"
        ],
        horizontal=True
    )

    st.divider()

    # -----------------------------
    # CHECK BALANCE
    # -----------------------------
    if menu == "💰 Check Balance":
        st.subheader("Current Balance")
        st.metric("Available Balance", f"₹{account['balance']:,.2f}")

    # -----------------------------
    # DEPOSIT
    # -----------------------------
    elif menu == "➕ Deposit":
        st.subheader("Deposit Money")

        amount = st.number_input(
            "Enter amount to deposit",
            min_value=1.0,
            step=100.0,
            format="%.2f"
        )

        if st.button("Deposit Money", type="primary", use_container_width=True):
            account["balance"] = round(account["balance"] + amount, 2)

            add_transaction(
                account,
                "Deposit",
                amount,
                "Money deposited"
            )

            save_accounts(accounts)

            st.success(f"₹{amount:,.2f} deposited successfully!")
            st.metric("New Balance", f"₹{account['balance']:,.2f}")

    # -----------------------------
    # WITHDRAW
    # -----------------------------
    elif menu == "➖ Withdraw":
        st.subheader("Withdraw Money")

        amount = st.number_input(
            "Enter amount to withdraw",
            min_value=1.0,
            step=100.0,
            format="%.2f"
        )

        if st.button("Withdraw Money", type="primary", use_container_width=True):
            if amount > account["balance"]:
                st.error("Insufficient balance.")
            else:
                account["balance"] = round(account["balance"] - amount, 2)

                add_transaction(
                    account,
                    "Withdrawal",
                    amount,
                    "Money withdrawn"
                )

                save_accounts(accounts)

                st.success(f"₹{amount:,.2f} withdrawn successfully!")
                st.metric("New Balance", f"₹{account['balance']:,.2f}")

    # -----------------------------
    # TRANSFER
    # -----------------------------
    elif menu == "🔄 Transfer":
        st.subheader("Transfer Money")

        other_accounts = [
            acc for acc in accounts.keys()
            if acc != account_number
        ]

        if not other_accounts:
            st.warning("No other bank accounts are available for transfer.")
        else:
            receiver_number = st.selectbox(
                "Select receiver account",
                other_accounts
            )

            amount = st.number_input(
                "Enter amount to transfer",
                min_value=1.0,
                step=100.0,
                format="%.2f"
            )

            if st.button("Transfer Money", type="primary", use_container_width=True):
                if amount > account["balance"]:
                    st.error("Insufficient balance.")
                else:
                    receiver = accounts[receiver_number]

                    account["balance"] = round(
                        account["balance"] - amount, 2
                    )

                    receiver["balance"] = round(
                        receiver["balance"] + amount, 2
                    )

                    add_transaction(
                        account,
                        "Transfer Sent",
                        amount,
                        f"To account {receiver_number}"
                    )

                    add_transaction(
                        receiver,
                        "Transfer Received",
                        amount,
                        f"From account {account_number}"
                    )

                    save_accounts(accounts)

                    st.success(
                        f"₹{amount:,.2f} transferred successfully "
                        f"to account {receiver_number}!"
                    )

    # -----------------------------
    # TRANSACTION HISTORY
    # -----------------------------
    elif menu == "📜 Transaction History":
        st.subheader("Transaction History")

        transactions = account.get("transactions", [])

        if not transactions:
            st.info("No transactions yet.")
        else:
            rows = []

            for index, transaction in enumerate(
                reversed(transactions), start=1
            ):
                rows.append({
                    "No.": index,
                    "Date & Time": transaction["date_time"],
                    "Type": transaction["type"],
                    "Amount": f"₹{transaction['amount']:,.2f}",
                    "Details": transaction["details"]
                })

            st.dataframe(
                rows,
                use_container_width=True,
                hide_index=True
            )

    # -----------------------------
    # CHANGE PIN
    # -----------------------------
    elif menu == "🔐 Change PIN":
        st.subheader("Change PIN")

        old_pin = st.text_input(
            "Old PIN",
            type="password",
            max_chars=4
        )

        new_pin = st.text_input(
            "New 4-digit PIN",
            type="password",
            max_chars=4
        )

        confirm_pin = st.text_input(
            "Confirm New PIN",
            type="password",
            max_chars=4
        )

        if st.button("Change PIN", type="primary", use_container_width=True):
            if old_pin != account["pin"]:
                st.error("Incorrect old PIN.")
            elif not valid_pin(new_pin):
                st.error("New PIN must contain exactly 4 digits.")
            elif new_pin != confirm_pin:
                st.error("New PINs do not match.")
            elif new_pin == old_pin:
                st.error("New PIN must be different from old PIN.")
            else:
                account["pin"] = new_pin
                save_accounts(accounts)
                st.success("PIN changed successfully!")

    # -----------------------------
    # LOGOUT
    # -----------------------------
    elif menu == "🚪 Logout":
        reset_session()
        st.success("Logged out successfully.")
        st.rerun()

# ============================================================
# MAIN MENU
# ============================================================
else:
    tab_create, tab_login = st.tabs(
        ["📝 Create Account", "🔑 Login"]
    )

    # -----------------------------
    # CREATE ACCOUNT
    # -----------------------------
    with tab_create:
        st.subheader("Create New Bank Account")

        name = st.text_input("Full Name")
        phone = st.text_input(
            "Phone Number",
            max_chars=10,
            placeholder="10-digit phone number"
        )

        pin = st.text_input(
            "Create 4-digit PIN",
            type="password",
            max_chars=4
        )

        confirm_pin = st.text_input(
            "Confirm PIN",
            type="password",
            max_chars=4
        )

        if st.button(
            "Create Account",
            type="primary",
            use_container_width=True
        ):
            name = name.strip()
            phone = phone.strip()

            if not name:
                st.error("Please enter your name.")

            elif not phone.isdigit() or len(phone) != 10:
                st.error("Please enter a valid 10-digit phone number.")

            elif not valid_pin(pin):
                st.error("PIN must contain exactly 4 digits.")

            elif pin != confirm_pin:
                st.error("PINs do not match.")

            else:
                account_number = generate_account_number(accounts)

                accounts[account_number] = {
                    "name": name,
                    "phone": phone,
                    "pin": pin,
                    "balance": 0.0,
                    "transactions": []
                }

                save_accounts(accounts)

                st.success("Account created successfully! 🎉")
                st.balloons()

                st.write("### Your Account Details")
                st.code(
                    f"Account Number: {account_number}\n"
                    f"Name: {name}\n"
                    f"Phone: {phone}"
                )

                st.warning(
                    "Save your account number and PIN. "
                    "You will need them to log in."
                )

    # -----------------------------
    # LOGIN
    # -----------------------------
    with tab_login:
        st.subheader("Login")

        login_account = st.text_input(
            "Account Number",
            placeholder="Enter your account number"
        )

        login_pin = st.text_input(
            "PIN",
            type="password",
            max_chars=4
        )

        if st.button(
            "Login",
            type="primary",
            use_container_width=True
        ):
            login_account = login_account.strip()

            if (
                login_account in accounts
                and accounts[login_account]["pin"] == login_pin
            ):
                st.session_state.logged_in = True
                st.session_state.account_number = login_account
                st.success("Login successful!")
                st.rerun()
            else:
                st.error("Invalid account number or PIN.")


# -----------------------------
# FOOTER
# -----------------------------
st.divider()
st.caption(
    "Educational mini-project — not intended for real banking or financial use."
)
