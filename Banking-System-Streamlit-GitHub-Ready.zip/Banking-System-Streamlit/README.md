# 🏦 Banking System – Streamlit Mini Project

A fully interactive Python banking mini-project built with **Streamlit**.

This project implements the requirements from the Banking System mini-project brief, including account creation, login, balance checking, deposits, withdrawals, transfers, transaction history, PIN changes, and logout.

## ✨ Features

- 📝 Create a bank account
- 🔢 Automatically generate a unique account number
- 🔐 Create and confirm a 4-digit PIN
- 🔑 Login using Account Number + PIN
- 💰 Check account balance
- ➕ Deposit money
- ➖ Withdraw money
- 🔄 Transfer money between accounts
- 📜 View transaction history
- 🔐 Change PIN
- 🚪 Logout
- 💾 Persistent local account data using JSON
- 🕒 Transaction date and time using `datetime`

## 🛠️ Technologies

- Python
- Streamlit
- JSON
- Random
- Datetime
- OS

## 📁 Project Structure

```text
Banking-System-Streamlit/
│
├── app.py
├── accounts.json
├── requirements.txt
├── README.md
└── .gitignore
```

## ▶️ Run Locally

### 1. Install dependencies

```bash
pip install -r requirements.txt
```

### 2. Start Streamlit

```bash
streamlit run app.py
```

The application will open in your browser.

## 🌐 Deploy on Streamlit Community Cloud

1. Create a GitHub repository.
2. Upload all project files.
3. Open Streamlit Community Cloud.
4. Select your GitHub repository.
5. Select branch:

```text
main
```

6. Set **Main file path** to:

```text
app.py
```

7. Click **Deploy**.

## 🧭 Application Flow

```text
                 BANKING SYSTEM
                       │
             ┌─────────┴─────────┐
             ↓                   ↓
       CREATE ACCOUNT          LOGIN
             │                   │
             ↓                   ↓
      Account Number + PIN   ACCOUNT MENU
                                 │
       ┌─────────────────────────┼────────────────────────┐
       ↓          ↓         ↓    ↓        ↓       ↓      ↓
    Balance    Deposit   Withdraw Transfer History Change Logout
```

## 💾 Data Storage

Account information is stored in:

```text
accounts.json
```

Example structure:

```json
{
    "1234567890": {
        "name": "Student",
        "phone": "9876543210",
        "pin": "1234",
        "balance": 5000.0,
        "transactions": []
    }
}
```

## 📚 Python Concepts Used

- Variables and data types
- Conditional statements
- Loops
- Functions
- Lists
- Dictionaries
- String operations
- Modules
- File handling
- JSON
- Exception handling
- Streamlit UI components
- Session state

## 🎯 Project Objective

The objective is to combine Python concepts learned so far into one real-world application and understand how individual concepts work together to build a functional banking system.

## 🌍 Real-World Connection

The application demonstrates a simplified version of concepts used in banking applications:

- Account management
- User authentication
- Balance management
- Money transactions
- Transaction records

## ⚠️ Important Security Note

This is an **educational mini-project**, not a real banking application.

The PIN is stored locally in `accounts.json` for demonstration purposes and is **not encrypted or hashed**. Do not use real banking credentials or financial information.

## 👨‍💻 Author

Student Mini Project – Banking System
